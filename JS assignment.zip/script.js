
//accessing the whole body of webpage
document.body.style.margin = "20px";
document.body.style.padding = "20px";
document.body.style.backgroundColor = "#b3e8ff";
document.body.style.border = "1px solid black";

//accessing Heading Section of Webpage and adding text, position and styles
document.getElementById("Heading").innerHTML = "Testbook's Competitive Exam Batch";
document.getElementById("Heading").style.textAlign = "center";
document.getElementById("Heading").style.padding = "20px";
document.getElementById("Heading").style.borderRadius = "20px";
document.getElementById("Heading").style.fontWeight = "bolder";
document.getElementById("Heading").style.backgroundColor = "#4dc9ff";
document.getElementById("Heading").style.fontSize = "45px";



//accessing the Intro of Webpage and adding text,styles to Intro Section
document.getElementById("Intro").innerHTML = "Improve your Learning Journey & Achieve your Success Milestone...!"
document.getElementById("Intro").style.fontSize = "20px";
document.getElementById("Intro").style.fontWeight = "bold"
document.getElementById("Intro").style.textAlign = "center";
document.getElementById("Intro").style.color = "purple";
document.getElementById("Intro").style.margin = "15px";
document.getElementById("Intro").style.backgroundColor = "#F3903a";
document.getElementById("Intro").style.padding = "19px";
document.getElementById("Intro").style.borderRadius = "20px";



//accessing the FeatureList of Webpage and adding text and styles to paragraph
document.getElementById("FeatureList").innerHTML = "Our Strength and Features";
document.getElementById("FeatureList").style.fontSize = "32px";
document.getElementById("FeatureList").style.fontWeight = "bold";
document.getElementById("FeatureList").style.color = "red";
document.getElementById("FeatureList").style.paddingLeft = "30%";
document.getElementById("FeatureList").style.textDecoration = "underline"



//accessing the Various Feature of Webpage and adding text and styles to it
document.getElementById("Feature1").innerHTML = "1. Best Teachers & Mentor Support";
document.getElementById("Feature1").style.paddingLeft = "30%";
document.getElementById("Feature1").style.fontSize = "22px";
document.getElementById("Feature1").style.fontWeight = "bold";


document.getElementById("Feature2").innerHTML = "2. Notes By Expert";
document.getElementById("Feature2").style.paddingLeft = "30%";
document.getElementById("Feature2").style.fontSize = "22px";
document.getElementById("Feature2").style.fontWeight = "bold";

document.getElementById("Feature3").innerHTML = "3. All Topics Covered & Full Preparation";
document.getElementById("Feature3").style.paddingLeft = "30%";
document.getElementById("Feature3").style.fontSize = "22px";
document.getElementById("Feature3").style.fontWeight = "bold";

document.getElementById("Feature4").innerHTML = "4. Weekly Mock Test Exams";
document.getElementById("Feature4").style.paddingLeft = "30%";
document.getElementById("Feature4").style.fontSize = "22px";
document.getElementById("Feature4").style.fontWeight = "bold";

document.getElementById("Feature5").innerHTML = "5. Best Content in Effective Price";
document.getElementById("Feature5").style.paddingLeft = "30%";
document.getElementById("Feature5").style.fontSize = "22px";
document.getElementById("Feature5").style.fontWeight = "bold";

//accessing the Course Section for adding text and styles to button
document.getElementById("Course").innerHTML = "Book Your Course Now";
document.getElementById("Course").style.marginLeft = "40%";
document.getElementById("Course").style.padding = "15px";
document.getElementById("Course").style.borderRadius = "15px";
document.getElementById("Course").style.backgroundColor = "lime"
document.getElementById("Course").style.fontWeight = "bold";














